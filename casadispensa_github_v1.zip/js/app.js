
let currentTab = "inventario";

function showTab(tab){
currentTab = tab;
document.getElementById("app").innerHTML = "<h2>"+tab+"</h2>";
}

document.addEventListener("backbutton", function(){

if(currentTab !== "inventario"){
showTab("inventario");
}else{
navigator.app.exitApp();
}

});
